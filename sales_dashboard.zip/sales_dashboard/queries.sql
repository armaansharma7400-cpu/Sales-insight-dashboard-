-- ============================================================
--  Sales Insights Dashboard : Key analytical queries
--  (These are the same ideas the Flask API runs behind the charts.
--   Run them in DB Browser for SQLite or:  sqlite3 sales.db < queries.sql)
-- ============================================================


-- Q1. Headline KPIs ------------------------------------------------
SELECT
    ROUND(SUM(revenue), 0)                      AS total_revenue,
    ROUND(SUM(profit), 0)                       AS total_profit,
    COUNT(*)                                    AS orders,
    SUM(quantity)                               AS units_sold,
    ROUND(SUM(revenue) / COUNT(*), 0)           AS avg_order_value,
    ROUND(100.0 * SUM(profit) / SUM(revenue), 1) AS profit_margin_pct
FROM vw_sales_detail;


-- Q2. Monthly revenue with month-on-month growth  (window function: LAG)
WITH monthly AS (
    SELECT month, SUM(revenue) AS revenue
    FROM vw_sales_detail
    GROUP BY month
)
SELECT
    month,
    ROUND(revenue, 0) AS revenue,
    ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month))
                / LAG(revenue) OVER (ORDER BY month), 1) AS mom_growth_pct
FROM monthly
ORDER BY month;


-- Q3. Revenue and margin by category
SELECT
    category,
    ROUND(SUM(revenue), 0)                        AS revenue,
    ROUND(SUM(profit), 0)                         AS profit,
    ROUND(100.0 * SUM(profit) / SUM(revenue), 1)  AS margin_pct,
    ROUND(100.0 * SUM(revenue) / (SELECT SUM(revenue) FROM vw_sales_detail), 1) AS share_pct
FROM vw_sales_detail
GROUP BY category
ORDER BY revenue DESC;


-- Q4. Top 3 products inside every category  (RANK + PARTITION BY)
SELECT category, product, revenue, rank_in_category
FROM (
    SELECT
        category,
        product,
        ROUND(SUM(revenue), 0) AS revenue,
        RANK() OVER (PARTITION BY category ORDER BY SUM(revenue) DESC) AS rank_in_category
    FROM vw_sales_detail
    GROUP BY category, product
)
WHERE rank_in_category <= 3
ORDER BY category, rank_in_category;


-- Q5. Region x Segment revenue matrix (conditional aggregation / pivot)
SELECT
    region,
    ROUND(SUM(CASE WHEN segment = 'Consumer'       THEN revenue END), 0) AS consumer,
    ROUND(SUM(CASE WHEN segment = 'Corporate'      THEN revenue END), 0) AS corporate,
    ROUND(SUM(CASE WHEN segment = 'Small Business' THEN revenue END), 0) AS small_business,
    ROUND(SUM(revenue), 0)                                               AS total
FROM vw_sales_detail
GROUP BY region
ORDER BY total DESC;


-- Q6. Customer loyalty: who are the top 10 and how much of revenue do they drive?
WITH cust AS (
    SELECT customer_id, customer, city, COUNT(*) AS orders, SUM(revenue) AS revenue
    FROM vw_sales_detail
    GROUP BY customer_id, customer, city
)
SELECT
    customer, city, orders, ROUND(revenue, 0) AS revenue,
    ROUND(100.0 * revenue / (SELECT SUM(revenue) FROM cust), 2) AS pct_of_total
FROM cust
ORDER BY revenue DESC
LIMIT 10;


-- Q7. Does discounting hurt? Margin by discount band
SELECT
    CASE
        WHEN discount_pct = 0   THEN '0%  (no discount)'
        WHEN discount_pct <= 10 THEN '5-10%'
        WHEN discount_pct <= 20 THEN '15-20%'
        ELSE '25%+'
    END AS discount_band,
    COUNT(*)                                       AS orders,
    ROUND(SUM(revenue), 0)                         AS revenue,
    ROUND(100.0 * SUM(profit) / SUM(revenue), 1)   AS margin_pct
FROM vw_sales_detail
GROUP BY discount_band
ORDER BY MIN(discount_pct);


-- Q8. Year-over-year comparison for each month (self-join on the monthly CTE)
WITH m AS (
    SELECT CAST(strftime('%Y', order_date) AS INT) AS yr,
           strftime('%m', order_date)              AS mm,
           SUM(revenue)                            AS revenue
    FROM vw_sales_detail
    GROUP BY yr, mm
)
SELECT
    a.mm AS month,
    ROUND(a.revenue, 0) AS rev_2025,
    ROUND(b.revenue, 0) AS rev_2026,
    ROUND(100.0 * (b.revenue - a.revenue) / a.revenue, 1) AS yoy_growth_pct
FROM m a
JOIN m b ON a.mm = b.mm AND a.yr = 2025 AND b.yr = 2026
ORDER BY a.mm;
