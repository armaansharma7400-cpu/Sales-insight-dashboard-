"""
app.py : Flask backend for the Sales Insights Dashboard.

Every chart on the page gets its data from a JSON endpoint here.
Each endpoint runs a parameterised SQL query on the vw_sales_detail view,
so all of them respond to the same three filters: year, region, category.

Run:  python app.py      then open  http://127.0.0.1:5000
"""
import csv
import io
import sqlite3
from pathlib import Path

from flask import Flask, Response, g, jsonify, render_template, request

BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "sales.db"

app = Flask(__name__)


# ------------------------------------------------------------------ db helpers
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def query(sql, params=()):
    return [dict(r) for r in get_db().execute(sql, params).fetchall()]


def build_filter():
    """Turn ?year=&region=&category= into a safe, parameterised WHERE clause."""
    clauses, params = [], []
    year = request.args.get("year", "")
    region = request.args.get("region", "")
    category = request.args.get("category", "")
    if year.isdigit():
        clauses.append("year = ?")
        params.append(int(year))
    if region:
        clauses.append("region = ?")
        params.append(region)
    if category:
        clauses.append("category = ?")
        params.append(category)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    return where, params


# ------------------------------------------------------------------ pages
@app.route("/")
def index():
    return render_template("index.html")


# ------------------------------------------------------------------ API
@app.route("/api/filters")
def api_filters():
    return jsonify(
        years=[r["year"] for r in query("SELECT DISTINCT year FROM vw_sales_detail ORDER BY year")],
        regions=[r["region"] for r in query("SELECT DISTINCT region FROM vw_sales_detail ORDER BY region")],
        categories=[r["category"] for r in query("SELECT DISTINCT category FROM vw_sales_detail ORDER BY category")],
    )


@app.route("/api/kpis")
def api_kpis():
    where, params = build_filter()
    row = query(f"""
        SELECT
            COALESCE(ROUND(SUM(revenue), 0), 0)  AS revenue,
            COALESCE(ROUND(SUM(profit), 0), 0)   AS profit,
            COUNT(*)                             AS orders,
            COALESCE(SUM(quantity), 0)           AS units,
            COALESCE(ROUND(SUM(revenue) / NULLIF(COUNT(*), 0), 0), 0)          AS aov,
            COALESCE(ROUND(100.0 * SUM(profit) / NULLIF(SUM(revenue), 0), 1), 0) AS margin
        FROM vw_sales_detail {where}
    """, params)[0]

    # Growth: last month in the filtered data vs the month before it
    months = query(f"""
        SELECT month, SUM(revenue) AS revenue
        FROM vw_sales_detail {where}
        GROUP BY month ORDER BY month DESC LIMIT 2
    """, params)
    growth = None
    if len(months) == 2 and months[1]["revenue"]:
        growth = round(100 * (months[0]["revenue"] - months[1]["revenue"]) / months[1]["revenue"], 1)
    row["growth"] = growth
    row["growth_month"] = months[0]["month"] if months else None
    return jsonify(row)


def linear_forecast(values, steps=3):
    """Fallback: plain least-squares line through the monthly revenue."""
    n = len(values)
    if n < 4:
        return []
    xs = list(range(n))
    mean_x, mean_y = sum(xs) / n, sum(values) / n
    denom = sum((x - mean_x) ** 2 for x in xs)
    slope = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, values)) / denom
    intercept = mean_y - slope * mean_x
    return [round(max(intercept + slope * (n + i), 0), 0) for i in range(steps)]


def seasonal_forecast(values, steps=3):
    """
    Seasonal-naive projection: next month = same month last year x recent growth.
    growth = (sum of the latest months) / (sum of the same months a year earlier).
    Respects festive-season spikes, which a straight line cannot.
    Needs at least 13 months of history, otherwise returns [].
    """
    n = len(values)
    if n < 13:
        return []
    window = min(12, n - 12)                       # months that have a year-ago partner
    recent = sum(values[n - window:])
    year_ago = sum(values[n - window - 12:n - 12])
    if year_ago <= 0:
        return []
    growth = recent / year_ago
    return [round(values[n + i - 12] * growth, 0) for i in range(steps)]


def next_months(last_month, steps):
    y, m = map(int, last_month.split("-"))
    out = []
    for _ in range(steps):
        m += 1
        if m == 13:
            y, m = y + 1, 1
        out.append(f"{y}-{m:02d}")
    return out


@app.route("/api/monthly")
def api_monthly():
    where, params = build_filter()
    rows = query(f"""
        WITH monthly AS (
            SELECT month, SUM(revenue) AS revenue, SUM(profit) AS profit
            FROM vw_sales_detail {where}
            GROUP BY month
        )
        SELECT month,
               ROUND(revenue, 0) AS revenue,
               ROUND(profit, 0)  AS profit,
               ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month))
                           / LAG(revenue) OVER (ORDER BY month), 1) AS mom_growth
        FROM monthly ORDER BY month
    """, params)

    forecast, method = [], None
    latest_month = query("SELECT MAX(month) AS m FROM vw_sales_detail")[0]["m"]
    # Only project forward when the view reaches the end of the data; for an older
    # year the "future" months already exist, so a projection would be meaningless.
    if rows and rows[-1]["month"] == latest_month:
        values = [r["revenue"] for r in rows]
        fc = seasonal_forecast(values)
        method = "seasonal"
        if not fc:                                  # under 13 months: fall back to a trend line
            fc = linear_forecast(values)
            method = "linear"
        forecast = [{"month": m, "revenue": v} for m, v in zip(next_months(rows[-1]["month"], len(fc)), fc)]
    return jsonify(history=rows, forecast=forecast, method=method)


@app.route("/api/category")
def api_category():
    where, params = build_filter()
    return jsonify(query(f"""
        SELECT category,
               ROUND(SUM(revenue), 0) AS revenue,
               ROUND(SUM(profit), 0)  AS profit,
               ROUND(100.0 * SUM(profit) / SUM(revenue), 1) AS margin
        FROM vw_sales_detail {where}
        GROUP BY category ORDER BY revenue DESC
    """, params))


@app.route("/api/region")
def api_region():
    where, params = build_filter()
    return jsonify(query(f"""
        SELECT region,
               ROUND(SUM(revenue), 0) AS revenue,
               COUNT(*)               AS orders
        FROM vw_sales_detail {where}
        GROUP BY region ORDER BY revenue DESC
    """, params))


@app.route("/api/segment")
def api_segment():
    where, params = build_filter()
    return jsonify(query(f"""
        SELECT segment, ROUND(SUM(revenue), 0) AS revenue
        FROM vw_sales_detail {where}
        GROUP BY segment ORDER BY revenue DESC
    """, params))


@app.route("/api/top-products")
def api_top_products():
    where, params = build_filter()
    return jsonify(query(f"""
        SELECT product, category,
               SUM(quantity)          AS units,
               ROUND(SUM(revenue), 0) AS revenue,
               ROUND(SUM(profit), 0)  AS profit
        FROM vw_sales_detail {where}
        GROUP BY product, category
        ORDER BY revenue DESC LIMIT 8
    """, params))


@app.route("/api/top-customers")
def api_top_customers():
    where, params = build_filter()
    return jsonify(query(f"""
        SELECT customer, city, segment,
               COUNT(*)               AS orders,
               ROUND(SUM(revenue), 0) AS revenue
        FROM vw_sales_detail {where}
        GROUP BY customer_id, customer, city, segment
        ORDER BY revenue DESC LIMIT 8
    """, params))


@app.route("/api/insights")
def api_insights():
    """Auto-generated plain-English findings, the 'so what?' of the dashboard."""
    where, params = build_filter()
    insights = []

    def money(v):
        return f"₹{v / 100000:.1f} L" if v < 10_000_000 else f"₹{v / 10_000_000:.2f} Cr"

    def month_name(ym):
        names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        y, m = ym.split("-")
        return f"{names[int(m) - 1]} {y}"

    cats = query(f"""
        SELECT category, SUM(revenue) AS revenue,
               100.0 * SUM(profit) / SUM(revenue) AS margin
        FROM vw_sales_detail {where} GROUP BY category
    """, params)
    total = sum(c["revenue"] for c in cats) or 1
    if cats:
        top = max(cats, key=lambda c: c["revenue"])
        insights.append(f"{top['category']} is the biggest category, bringing in "
                        f"{money(top['revenue'])} ({100 * top['revenue'] / total:.0f}% of revenue).")
        best_margin = max(cats, key=lambda c: c["margin"])
        if best_margin["category"] != top["category"]:
            insights.append(f"{best_margin['category']} has the healthiest margin at "
                            f"{best_margin['margin']:.0f}%, higher than {top['category']} "
                            f"at {next(c['margin'] for c in cats if c['category'] == top['category']):.0f}%.")

    months = query(f"""
        SELECT month, SUM(revenue) AS revenue
        FROM vw_sales_detail {where} GROUP BY month ORDER BY revenue DESC
    """, params)
    if months:
        insights.append(f"Best month: {month_name(months[0]['month'])} with {money(months[0]['revenue'])} in sales.")

    regs = query(f"""
        SELECT region, SUM(revenue) AS revenue
        FROM vw_sales_detail {where} GROUP BY region ORDER BY revenue DESC
    """, params)
    if len(regs) >= 2:
        insights.append(f"{regs[0]['region']} leads all regions; {regs[-1]['region']} is the weakest "
                        f"and the clearest opportunity to grow.")

    disc = query(f"""
        SELECT
          100.0 * SUM(CASE WHEN discount_pct >= 15 THEN profit END) /
          NULLIF(SUM(CASE WHEN discount_pct >= 15 THEN revenue END), 0) AS heavy,
          100.0 * SUM(CASE WHEN discount_pct = 0 THEN profit END) /
          NULLIF(SUM(CASE WHEN discount_pct = 0 THEN revenue END), 0)  AS none
        FROM vw_sales_detail {where}
    """, params)[0]
    if disc["heavy"] is not None and disc["none"] is not None:
        insights.append(f"Orders with 15%+ discounts earn a {disc['heavy']:.0f}% margin versus "
                        f"{disc['none']:.0f}% with no discount, so deep discounts trade profit for volume.")
    return jsonify(insights)


@app.route("/api/export.csv")
def export_csv():
    """Download the currently filtered rows as CSV (opens straight in Excel)."""
    where, params = build_filter()
    rows = get_db().execute(f"""
        SELECT sale_id, order_date, customer, city, region, segment,
               product, category, quantity, discount_pct, revenue, profit
        FROM vw_sales_detail {where} ORDER BY order_date DESC
    """, params).fetchall()
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["sale_id", "order_date", "customer", "city", "region", "segment",
                     "product", "category", "quantity", "discount_pct", "revenue", "profit"])
    writer.writerows(rows)
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=sales_export.csv"})


if __name__ == "__main__":
    if not DB_PATH.exists():
        raise SystemExit("sales.db not found. Run:  python generate_data.py  first.")
    app.run(debug=True)
