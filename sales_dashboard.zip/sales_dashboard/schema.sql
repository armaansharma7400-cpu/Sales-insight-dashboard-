-- ============================================================
--  Sales Insights Dashboard : Database Schema (SQLite)
--  Star-style design: 2 dimension tables + 1 fact table + 1 view
-- ============================================================

DROP VIEW  IF EXISTS vw_sales_detail;
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

-- Dimension: who bought
CREATE TABLE customers (
    customer_id INTEGER PRIMARY KEY,
    name        TEXT NOT NULL,
    city        TEXT NOT NULL,
    region      TEXT NOT NULL CHECK (region IN ('North','South','East','West')),
    segment     TEXT NOT NULL CHECK (segment IN ('Consumer','Corporate','Small Business'))
);

-- Dimension: what was sold
CREATE TABLE products (
    product_id INTEGER PRIMARY KEY,
    name       TEXT NOT NULL,
    category   TEXT NOT NULL,
    unit_price REAL NOT NULL CHECK (unit_price > 0),
    unit_cost  REAL NOT NULL CHECK (unit_cost > 0)
);

-- Fact: one row per order line
CREATE TABLE sales (
    sale_id      INTEGER PRIMARY KEY,
    order_date   TEXT    NOT NULL,              -- ISO format YYYY-MM-DD
    customer_id  INTEGER NOT NULL REFERENCES customers(customer_id),
    product_id   INTEGER NOT NULL REFERENCES products(product_id),
    quantity     INTEGER NOT NULL CHECK (quantity > 0),
    discount_pct REAL    NOT NULL DEFAULT 0 CHECK (discount_pct BETWEEN 0 AND 50)
);

-- Speed up the filters / group-bys used by the dashboard
CREATE INDEX idx_sales_date     ON sales(order_date);
CREATE INDEX idx_sales_customer ON sales(customer_id);
CREATE INDEX idx_sales_product  ON sales(product_id);

-- Analytics view: joins everything and derives revenue + profit once,
-- so every dashboard query stays short and readable.
CREATE VIEW vw_sales_detail AS
SELECT
    s.sale_id,
    s.order_date,
    CAST(strftime('%Y', s.order_date) AS INTEGER) AS year,
    strftime('%Y-%m', s.order_date)               AS month,
    c.customer_id,
    c.name       AS customer,
    c.city,
    c.region,
    c.segment,
    p.product_id,
    p.name       AS product,
    p.category,
    s.quantity,
    s.discount_pct,
    ROUND(s.quantity * p.unit_price * (1 - s.discount_pct / 100.0), 2)                  AS revenue,
    ROUND(s.quantity * (p.unit_price * (1 - s.discount_pct / 100.0) - p.unit_cost), 2)  AS profit
FROM sales s
JOIN customers c ON c.customer_id = s.customer_id
JOIN products  p ON p.product_id  = s.product_id;
