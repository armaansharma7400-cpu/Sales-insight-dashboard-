# Sales Insights Dashboard

A data analytics project that turns raw retail sales records into an interactive dashboard.
SQL does the analysis, Python serves it, and an HTML/CSS/JavaScript front end shows it.

**MCA Final Year Project** (replace with your name, roll number and guide)

---

## 1. What it does

- Stores 7,336 sales records (650 customers, 25 products, Jan 2025 to Oct 2026) in a SQLite database
- Answers business questions with SQL: growth, best categories, weakest regions, effect of discounts
- Shows the answers on a dashboard with five KPIs, a trend chart, bar charts and ranked tables
- Filters everything by **year, region and category** at once
- Writes plain-English **insights** automatically ("Electronics is the biggest category...")
- Projects the next 3 months of revenue using last year's seasonal pattern
- Exports the filtered data to CSV (opens in Excel)
- Works in light and dark mode, on laptop and phone, and fully **offline** (no external libraries)

## 2. Tech stack

| Layer | Technology | Role |
|---|---|---|
| Database | SQLite + SQL | Tables, a view, joins, CTEs, window functions |
| Backend | Python 3 + Flask | Runs the queries, exposes a JSON API |
| Frontend | HTML, CSS, JavaScript | Dashboard page and hand-drawn SVG charts |
| Data | Python script | Generates realistic sample data |

## 3. How to run

```
cd sales_dashboard
python -m venv venv
venv\Scripts\activate          (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
python generate_data.py        (creates sales.db; optional, the file is already included)
python app.py
```

Open **http://127.0.0.1:5000** in a browser.

Handy links for a live demo:
- `/?year=2026&region=North` opens a pre-filtered view
- `/?theme=dark` opens in dark mode

## 4. Project structure

```
sales_dashboard/
  schema.sql         table definitions, indexes and the analytics view
  generate_data.py   builds sales.db with sample data
  queries.sql        8 analytical queries to explain in your viva
  app.py             Flask app: pages + JSON API
  templates/
    index.html       dashboard page
  static/
    style.css        layout, colours, light/dark theme
    app.js           fetches data, draws charts, handles filters
  requirements.txt   Python dependency (Flask)
```

## 5. Database design

Two dimension tables and one fact table (a small star schema):

```
customers                 sales (fact)                products
-----------               -------------------         ------------
customer_id  PK  <----    customer_id  FK             product_id  PK
name                      product_id   FK   ---->     name
city                      sale_id      PK             category
region                    order_date                  unit_price
segment                   quantity                    unit_cost
                          discount_pct
```

`vw_sales_detail` is a **view** that joins all three tables and calculates:

- `revenue = quantity x unit_price x (1 - discount)`
- `profit  = quantity x (discounted price - unit_cost)`

Every dashboard query reads from this view, which keeps the SQL short and avoids repeating the joins.

## 6. SQL concepts demonstrated (see `queries.sql`)

| Concept | Where |
|---|---|
| JOIN, GROUP BY, aggregate functions | Q1, Q3, the view |
| CTE (WITH clause) | Q2, Q6, Q8 |
| Window functions: `LAG`, `RANK ... PARTITION BY` | Q2, Q4 |
| Conditional aggregation (pivot with CASE) | Q5, Q7 |
| Subquery | Q3, Q6 |
| Self-join on a CTE (year-over-year) | Q8 |
| View, indexes, CHECK and FOREIGN KEY constraints | `schema.sql` |
| Parameterised queries (prevents SQL injection) | `app.py` |

## 7. What the analysis found

(Based on the generated data; the patterns were built into it so the analysis has something to discover.)

1. **Revenue is growing**, with a festive-season spike in October to December.
2. **Electronics earns the most** (37% of revenue) but at only a 35% margin.
3. **Stationery has the best margin** (59%) but the smallest sales.
4. **East is the weakest region**, about half of South or West.
5. **Deep discounts cost profit.** Orders with 15% or more off earn a 32% margin, against 44% with no discount.
6. About 8% of customers are loyal repeat buyers who account for a large share of orders.

## 8. How to present it (about 10 minutes)

| Slide | Content | Time |
|---|---|---|
| 1 | Title, your name, guide | 0:20 |
| 2 | Problem: businesses have sales data but need answers, not rows | 0:40 |
| 3 | Objectives: analyse, visualise, give insights | 0:40 |
| 4 | Tech stack and architecture (SQL, Flask API, browser) | 1:00 |
| 5 | Database design: the schema diagram from section 5 | 1:00 |
| 6 | SQL highlights: show Q2 (LAG) and Q4 (RANK) | 1:00 |
| 7 | **Live demo** (see below) | 3:00 |
| 8 | Findings and business recommendations (section 7) | 1:00 |
| 9 | Limitations and future scope | 0:40 |
| 10 | Conclusion and questions | 0:20 |

**Live demo flow**
1. Show the KPI strip and say what each number means
2. Hover over the trend chart and point out the October peak
3. Read the "What the data says" panel aloud
4. Change **Region to East** and watch every number update together
5. Click **Table view**, then **Download CSV**
6. Flip to dark mode

**Architecture in one sentence:** the browser asks Flask for JSON, Flask runs a parameterised SQL query on the view, and JavaScript draws the result.

## 9. Likely viva questions

**Why SQLite?** It needs no installation and suits a single-user analytics project. The same SQL works on MySQL or PostgreSQL with small changes (mainly date functions).

**Why a view?** It joins and calculates revenue and profit once, so every query is shorter and the logic lives in one place.

**How do you prevent SQL injection?** Filter values go in as bound parameters (`?`), never into the SQL text. The `year` filter is also checked with `isdigit()`.

**How does the projection work?** Next month = the same month last year x recent growth, where growth is the sum of recent months divided by the same months a year earlier. With under 13 months of data it falls back to a straight trend line. It is a simple method, not a full forecasting model.

**Why no Chart.js?** The charts are plain SVG drawn in JavaScript, so the dashboard has no dependencies and works offline during a presentation.

**Is the data real?** No, it is generated by `generate_data.py` with a fixed random seed. That keeps the demo reproducible. To use real data, load a CSV into the `sales`, `customers` and `products` tables and the dashboard works unchanged.

**What is the month-on-month growth figure?** The latest month's revenue compared with the month before it. Because of festive seasonality, October looks very strong against September.

## 10. Limitations and future scope

- Sample data, not live business data
- Simple projection; could be replaced with ARIMA or Prophet
- No login or user roles
- Future: upload your own CSV, scheduled email reports, customer segmentation (RFM analysis), deployment on a cloud server
