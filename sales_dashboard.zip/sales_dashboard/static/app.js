/*
 * app.js : front-end logic for the Sales Insights Dashboard.
 *
 * Flow:  filters change -> fetch 8 JSON endpoints -> render KPIs, SVG chart,
 *        bars, tables and insights.  No libraries: the charts are drawn as SVG
 *        here, so the page works offline (handy for a live presentation).
 */
(() => {
  'use strict';

  const $ = (sel) => document.querySelector(sel);
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const inr = new Intl.NumberFormat('en-IN');

  // ------------------------------------------------------------ formatting
  const trim = (n) => String(Math.round(n * 10) / 10);

  function money(v) {                       // Indian style: lakh / crore
    if (v >= 1e7) return '₹' + (v / 1e7).toFixed(2) + ' Cr';
    if (v >= 1e5) return '₹' + (v / 1e5).toFixed(1) + ' L';
    return '₹' + inr.format(Math.round(v));
  }
  function axisMoney(v) {
    if (v === 0) return '₹0';
    if (v >= 1e7) return '₹' + trim(v / 1e7) + 'Cr';
    if (v >= 1e5) return '₹' + trim(v / 1e5) + 'L';
    return '₹' + trim(v / 1e3) + 'K';
  }
  function monthLabel(ym, long) {           // '2026-10' -> 'Oct 26' / 'Oct 2026'
    const [y, m] = ym.split('-');
    return MONTHS[Number(m) - 1] + ' ' + (long ? y : y.slice(2));
  }
  function niceScale(max, ticks) {          // friendly axis steps (1, 2, 2.5, 5 x 10^n)
    const raw = max / ticks;
    const mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const n = raw / mag;
    const step = (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * mag;
    return { step, max: step * Math.ceil(max / step) };
  }

  // ------------------------------------------------------------ DOM helpers
  function h(tag, cls, text, parent) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;       // textContent only: data is never parsed as HTML
    if (parent) parent.appendChild(n);
    return n;
  }
  function svgEl(tag, attrs, parent) {
    const n = document.createElementNS(SVG_NS, tag);
    for (const [k, v] of Object.entries(attrs || {})) n.setAttribute(k, v);
    if (parent) parent.appendChild(n);
    return n;
  }
  function empty(box) {
    box.replaceChildren();
    h('p', 'empty', 'No sales match these filters. Change a filter or reset them to see everything.', box);
  }

  // ------------------------------------------------------------ tooltip
  const tip = $('#tip');

  function showTip(cx, cy, title, lines) {
    tip.replaceChildren();
    h('div', 'tip-title', title, tip);
    lines.forEach((l) => {
      if (l.note) { h('div', 'tip-note', l.note, tip); return; }
      const row = h('div', 'tip-line', null, tip);
      h('span', 'tip-key ' + (l.key || ''), null, row);
      h('strong', null, l.value, row);                // value leads, label follows
      h('span', 'lbl', l.label, row);
    });
    tip.hidden = false;
    const w = tip.offsetWidth, hgt = tip.offsetHeight;
    let left = cx + 14, top = cy + 14;
    if (left + w > window.innerWidth - 8) left = cx - 14 - w;
    if (top + hgt > window.innerHeight - 8) top = cy - 14 - hgt;
    tip.style.left = Math.max(8, left) + 'px';
    tip.style.top = Math.max(8, top) + 'px';
  }
  const hideTip = () => { tip.hidden = true; };

  function attachTip(el, build) {
    const show = (cx, cy) => { const t = build(); showTip(cx, cy, t.title, t.lines); };
    el.addEventListener('pointermove', (e) => show(e.clientX, e.clientY));
    el.addEventListener('pointerleave', hideTip);
    el.addEventListener('focus', () => {
      const r = el.getBoundingClientRect();
      show(r.left + r.width / 2, r.top + r.height / 2);
    });
    el.addEventListener('blur', hideTip);
  }

  // ------------------------------------------------------------ tables
  function buildTable(parent, cols, rows) {
    parent.replaceChildren();
    if (!rows.length) return empty(parent);
    const t = h('table', 'data', null, parent);
    const head = t.createTHead().insertRow();
    cols.forEach((c) => {
      const th = h('th', c.num ? 'num' : '', c.head, head);
      th.scope = 'col';
    });
    const body = t.createTBody();
    rows.forEach((r) => {
      const tr = body.insertRow();
      cols.forEach((c) => {
        const td = tr.insertCell();
        if (c.num) td.className = 'num';
        const v = c.cell(r);
        if (v instanceof Node) td.appendChild(v); else td.textContent = v;
      });
    });
  }
  function twoLine(main, sub) {
    const s = h('span', null, main);
    h('small', null, sub, s);
    return s;
  }

  // ------------------------------------------------------------ horizontal bars
  function renderBars(box, rows, opts) {
    box.replaceChildren();
    if (!rows.length) return empty(box);
    const max = Math.max(...rows.map((r) => r.revenue), 1);
    rows.forEach((r) => {
      const row = h('div', 'bar-row', null, box);
      row.tabIndex = 0;
      h('div', 'bar-name', r[opts.key], row);
      const track = h('div', 'bar-track', null, row);
      const fill = h('div', 'bar-fill', null, track);
      fill.style.width = (r.revenue / max * 100) + '%';
      const val = h('div', 'bar-val', money(r.revenue), row);
      if (opts.sub) h('small', null, opts.sub(r), val);
      attachTip(row, () => ({ title: r[opts.key], lines: opts.tip(r) }));
    });
  }

  // ------------------------------------------------------------ KPIs
  function renderKpis(k) {
    $('#vRevenue').textContent = money(k.revenue);
    $('#vProfit').textContent = money(k.profit);
    $('#vOrders').textContent = inr.format(k.orders);
    $('#vAov').textContent = '₹' + inr.format(k.aov);
    $('#vMargin').textContent = k.margin.toFixed(1) + '%';

    const g = $('#nRevenue');
    if (k.growth == null) {
      g.className = 'kpi-note';
      g.textContent = 'No earlier month to compare';
      g.removeAttribute('title');
    } else {
      const up = k.growth >= 0;
      g.className = 'kpi-note ' + (up ? 'up' : 'down');
      g.textContent = (up ? '▲ ' : '▼ ') + Math.abs(k.growth).toFixed(1) + '% vs previous month';
      g.title = 'Latest month in view: ' + monthLabel(k.growth_month, true);
    }
    $('#nProfit').textContent = k.orders ? money(k.profit / k.orders) + ' per order' : '';
    $('#nOrders').textContent = inr.format(k.units) + ' units sold';
    $('#viewCount').textContent = inr.format(k.orders) + ' orders in view';
  }

  // ------------------------------------------------------------ trend chart
  let trendData = null;
  let trendAsTable = false;

  function drawTrend() {
    const box = $('#trend');
    box.replaceChildren();
    const d = trendData;
    const legendProj = $('#legendProj');
    if (legendProj) legendProj.hidden = !(d && d.forecast.length);   // no projection, no legend entry
    if (!d || !d.history.length) return empty(box);
    if (trendAsTable) return drawTrendTable(box, d);

    const pts = d.history
      .map((r) => ({ month: r.month, revenue: r.revenue, profit: r.profit, mom: r.mom_growth, proj: false }))
      .concat(d.forecast.map((r) => ({ month: r.month, revenue: r.revenue, profit: null, mom: null, proj: true })));
    const nHist = d.history.length, n = pts.length;

    const W = Math.max(300, box.clientWidth);
    const H = W < 520 ? 250 : 320;
    const m = { t: 14, r: W < 520 ? 58 : 76, b: 30, l: 56 };
    const iW = W - m.l - m.r, iH = H - m.t - m.b;
    const sc = niceScale(Math.max(...pts.map((p) => p.revenue)), 4);
    const x = (i) => (n === 1 ? m.l + iW / 2 : m.l + (iW * i) / (n - 1));
    const y = (v) => m.t + iH - (v / sc.max) * iH;

    const summary = 'Monthly revenue and profit from ' + monthLabel(pts[0].month, true) +
      ' to ' + monthLabel(pts[nHist - 1].month, true) +
      (d.forecast.length ? ', with a three month trend projection.' : '.');
    const svg = svgEl('svg', { width: W, height: H, viewBox: '0 0 ' + W + ' ' + H, role: 'img', tabindex: 0, 'aria-label': summary }, box);

    // projection band
    if (d.forecast.length) {
      svgEl('rect', { class: 'proj-band', x: x(nHist - 1), y: m.t, width: x(n - 1) - x(nHist - 1), height: iH }, svg);
      const t = svgEl('text', { class: 'axis-label', x: x(nHist - 1) + 6, y: m.t + 13 }, svg);
      t.textContent = 'Projected';
    }

    // y grid + labels
    for (let v = 0; v <= sc.max + 1; v += sc.step) {
      svgEl('line', { class: v === 0 ? 'baseline' : 'grid', x1: m.l, x2: W - m.r, y1: y(v), y2: y(v) }, svg);
      const t = svgEl('text', { class: 'axis-label', x: m.l - 8, y: y(v), 'text-anchor': 'end', dy: '0.32em' }, svg);
      t.textContent = axisMoney(v);
    }
    // x labels
    const every = Math.ceil(n / Math.max(2, Math.floor(iW / 54)));
    pts.forEach((p, i) => {
      if (i % every) return;
      const t = svgEl('text', { class: 'axis-label', x: x(i), y: H - 9, 'text-anchor': 'middle' }, svg);
      t.textContent = monthLabel(p.month);
    });

    // lines
    const path = (from, to, key) => {
      let s = '';
      for (let i = from; i <= to; i++) s += (i === from ? 'M' : 'L') + x(i).toFixed(1) + ',' + y(pts[i][key]).toFixed(1);
      return s;
    };
    if (d.forecast.length) svgEl('path', { class: 'line line-proj', d: path(nHist - 1, n - 1, 'revenue') }, svg);
    svgEl('path', { class: 'line line-rev', d: path(0, nHist - 1, 'revenue') }, svg);
    svgEl('path', { class: 'line line-prof', d: path(0, nHist - 1, 'profit') }, svg);

    // end markers + direct labels (value text stays in ink, colour only on marks)
    const last = pts[nHist - 1];
    svgEl('circle', { class: 'dot dot-rev', r: 4, cx: x(nHist - 1), cy: y(last.revenue) }, svg);
    svgEl('circle', { class: 'dot dot-prof', r: 4, cx: x(nHist - 1), cy: y(last.profit) }, svg);
    const revEnd = pts[n - 1];
    svgEl('text', { class: 'direct', x: x(n - 1) + 8, y: y(revEnd.revenue), dy: '0.32em' }, svg).textContent = 'Revenue';
    svgEl('text', { class: 'direct', x: x(nHist - 1) + 8, y: y(last.profit), dy: '0.32em' }, svg).textContent = 'Profit';

    // hover layer: crosshair snaps to the nearest month
    const hair = svgEl('line', { class: 'xhair', y1: m.t, y2: m.t + iH, visibility: 'hidden' }, svg);
    const hr = svgEl('circle', { class: 'dot dot-rev', r: 5, visibility: 'hidden' }, svg);
    const hp = svgEl('circle', { class: 'dot dot-prof', r: 5, visibility: 'hidden' }, svg);
    let idx = nHist - 1;

    function clear() {
      [hair, hr, hp].forEach((e) => e.setAttribute('visibility', 'hidden'));
      hideTip();
    }
    function hover(i, cx, cy) {
      idx = i;
      const p = pts[i];
      hair.setAttribute('x1', x(i)); hair.setAttribute('x2', x(i));
      hair.setAttribute('visibility', 'visible');
      hr.setAttribute('cx', x(i)); hr.setAttribute('cy', y(p.revenue)); hr.setAttribute('visibility', 'visible');
      if (p.profit != null) {
        hp.setAttribute('cx', x(i)); hp.setAttribute('cy', y(p.profit)); hp.setAttribute('visibility', 'visible');
      } else hp.setAttribute('visibility', 'hidden');

      const lines = [{ key: 'k-rev', value: money(p.revenue), label: p.proj ? 'Revenue (projected)' : 'Revenue' }];
      if (p.profit != null) lines.push({ key: 'k-prof', value: money(p.profit), label: 'Profit' });
      if (p.mom != null) lines.push({ value: (p.mom > 0 ? '+' : '') + p.mom.toFixed(1) + '%', label: 'vs previous month' });
      if (p.proj) {
        lines.push({
          note: d.method === 'seasonal'
            ? 'Same month last year, scaled by recent growth.'
            : 'Straight-line trend. Needs 13+ months to model seasons.',
        });
      }
      showTip(cx, cy, monthLabel(p.month, true), lines);
    }
    svg.addEventListener('pointermove', (e) => {
      const r = svg.getBoundingClientRect();
      const step = n === 1 ? 1 : iW / (n - 1);
      const i = n === 1 ? 0 : Math.max(0, Math.min(n - 1, Math.round((e.clientX - r.left - m.l) / step)));
      hover(i, e.clientX, e.clientY);
    });
    svg.addEventListener('pointerleave', clear);
    svg.addEventListener('blur', clear);
    const kbd = (i) => {
      const r = svg.getBoundingClientRect();
      hover(i, r.left + x(i), r.top + y(pts[i].revenue));
    };
    svg.addEventListener('focus', () => kbd(idx));
    svg.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight') { e.preventDefault(); kbd(Math.min(n - 1, idx + 1)); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); kbd(Math.max(0, idx - 1)); }
    });
  }

  function drawTrendTable(box, d) {
    const wrap = h('div', 'table-scroll', null, box);
    const rows = d.history.map((r) => ({ ...r, proj: false }))
      .concat(d.forecast.map((r) => ({ month: r.month, revenue: r.revenue, profit: null, mom_growth: null, proj: true })));
    buildTable(wrap, [
      { head: 'Month', cell: (r) => monthLabel(r.month, true) + (r.proj ? ' (projected)' : '') },
      { head: 'Revenue', num: true, cell: (r) => money(r.revenue) },
      { head: 'Profit', num: true, cell: (r) => (r.profit == null ? '-' : money(r.profit)) },
      { head: 'Vs previous month', num: true, cell: (r) => (r.mom_growth == null ? '-' : (r.mom_growth > 0 ? '+' : '') + r.mom_growth.toFixed(1) + '%') },
    ], rows);
  }

  // ------------------------------------------------------------ data loading
  const state = { year: '', region: '', category: '' };
  let requestId = 0;

  const queryString = () => new URLSearchParams(Object.entries(state).filter(([, v]) => v)).toString();
  const api = (path) => {
    const q = queryString();
    return fetch('/api/' + path + (q ? '?' + q : '')).then((r) => {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  };

  async function loadAll() {
    const token = ++requestId;
    const main = $('#main');
    main.classList.add('loading');
    const q = queryString();
    $('#exportBtn').href = '/api/export.csv' + (q ? '?' + q : '');
    try {
      const [kpis, monthly, cat, reg, seg, prod, cust, ins] = await Promise.all([
        api('kpis'), api('monthly'), api('category'), api('region'),
        api('segment'), api('top-products'), api('top-customers'), api('insights'),
      ]);
      if (token !== requestId) return;               // a newer filter change won the race

      renderKpis(kpis);
      trendData = monthly;
      drawTrend();

      renderBars($('#catBars'), cat, {
        key: 'category',
        sub: (r) => r.margin.toFixed(0) + '% margin',
        tip: (r) => [
          { value: money(r.revenue), label: 'Revenue' },
          { value: money(r.profit), label: 'Profit' },
          { value: r.margin.toFixed(1) + '%', label: 'Profit margin' },
        ],
      });
      renderBars($('#regBars'), reg, {
        key: 'region',
        tip: (r) => [
          { value: money(r.revenue), label: 'Revenue' },
          { value: inr.format(r.orders), label: 'Orders' },
        ],
      });
      renderBars($('#segBars'), seg, {
        key: 'segment',
        tip: (r) => [{ value: money(r.revenue), label: 'Revenue' }],
      });

      buildTable($('#prodTable'), [
        { head: 'Product', cell: (r) => twoLine(r.product, r.category) },
        { head: 'Units', num: true, cell: (r) => inr.format(r.units) },
        { head: 'Revenue', num: true, cell: (r) => money(r.revenue) },
        { head: 'Profit', num: true, cell: (r) => money(r.profit) },
      ], prod);
      buildTable($('#custTable'), [
        { head: 'Customer', cell: (r) => twoLine(r.customer, r.city) },
        { head: 'Segment', cell: (r) => r.segment },
        { head: 'Orders', num: true, cell: (r) => inr.format(r.orders) },
        { head: 'Revenue', num: true, cell: (r) => money(r.revenue) },
      ], cust);

      const list = $('#insightList');
      list.replaceChildren();
      if (!ins.length) h('li', null, 'Not enough data in this view to draw conclusions.', list);
      ins.forEach((t) => h('li', null, t, list));

      $('#error').hidden = true;
    } catch (err) {
      if (token !== requestId) return;
      $('#error').hidden = false;
      console.error(err);
    } finally {
      if (token === requestId) main.classList.remove('loading');
    }
  }

  // ------------------------------------------------------------ controls
  function fillSelect(sel, allLabel, values) {
    sel.replaceChildren();
    h('option', null, allLabel, sel).value = '';
    values.forEach((v) => { h('option', null, String(v), sel).value = String(v); });
  }

  function setupTheme() {
    const root = document.documentElement;
    const btn = $('#themeBtn');
    const isDark = () => (root.dataset.theme
      ? root.dataset.theme === 'dark'
      : window.matchMedia('(prefers-color-scheme: dark)').matches);
    const label = () => { btn.textContent = isDark() ? 'Light mode' : 'Dark mode'; };
    try {
      const saved = localStorage.getItem('theme');
      if (saved) root.dataset.theme = saved;
    } catch (_) { /* storage can be blocked: ignore */ }
    const forced = new URLSearchParams(window.location.search).get('theme');   // /?theme=dark
    if (forced === 'dark' || forced === 'light') root.dataset.theme = forced;
    label();
    btn.addEventListener('click', () => {
      const next = isDark() ? 'light' : 'dark';
      root.dataset.theme = next;
      try { localStorage.setItem('theme', next); } catch (_) { /* ignore */ }
      label();
    });
  }

  async function init() {
    setupTheme();
    try {
      const f = await fetch('/api/filters').then((r) => r.json());
      fillSelect($('#fYear'), 'All years', f.years);
      fillSelect($('#fRegion'), 'All regions', f.regions);
      fillSelect($('#fCategory'), 'All categories', f.categories);
    } catch (err) {
      $('#error').hidden = false;
      return;
    }

    const fromUrl = new URLSearchParams(window.location.search);   // e.g. /?year=2026&region=North
    [['#fYear', 'year'], ['#fRegion', 'region'], ['#fCategory', 'category']].forEach(([sel, key]) => {
      const wanted = fromUrl.get(key);
      if (wanted && [...$(sel).options].some((o) => o.value === wanted)) {
        $(sel).value = wanted;
        state[key] = wanted;
      }
      $(sel).addEventListener('change', (e) => { state[key] = e.target.value; loadAll(); });
    });
    $('#resetBtn').addEventListener('click', () => {
      state.year = state.region = state.category = '';
      ['#fYear', '#fRegion', '#fCategory'].forEach((s) => { $(s).value = ''; });
      loadAll();
    });
    $('#tableToggle').addEventListener('click', (e) => {
      trendAsTable = !trendAsTable;
      e.currentTarget.setAttribute('aria-pressed', String(trendAsTable));
      e.currentTarget.textContent = trendAsTable ? 'Chart view' : 'Table view';
      drawTrend();
    });

    // redraw the SVG when the panel width changes (window resize, rotate phone)
    let lastW = 0;
    new ResizeObserver(() => {
      const w = $('#trend').clientWidth;
      if (w && Math.abs(w - lastW) > 1) { lastW = w; drawTrend(); }
    }).observe($('#trend'));

    loadAll();
  }

  init();
})();
