"""
generate_data.py
Creates sales.db (SQLite) and fills it with realistic synthetic retail data
for an Indian e-commerce style business: Jan 2025 -> Oct 2026.

Built-in patterns, so the analysis has real stories to find:
  * steady month-on-month growth
  * festive-season spike (Oct-Dec, Diwali) and a mid-year dip
  * regional differences (West & South buy more)
  * Electronics earns the most revenue, Stationery the best margin
  * occasional discounts that reduce profit

Run:  python generate_data.py
"""
import random
import sqlite3
from datetime import date, timedelta
from pathlib import Path

random.seed(42)  # same data every run -> reproducible demo

BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "sales.db"
SCHEMA_PATH = BASE_DIR / "schema.sql"

START, END = date(2025, 1, 1), date(2026, 10, 31)

# ---------------------------------------------------------------- reference data
CITIES = {
    "North": ["Delhi", "Ludhiana", "Chandigarh", "Jaipur", "Lucknow"],
    "South": ["Bengaluru", "Chennai", "Hyderabad", "Kochi"],
    "East":  ["Kolkata", "Bhubaneswar", "Patna", "Guwahati"],
    "West":  ["Mumbai", "Pune", "Ahmedabad", "Surat"],
}
REGION_WEIGHT = {"North": 0.27, "South": 0.27, "East": 0.14, "West": 0.32}

FIRST = ["Aarav", "Vivaan", "Aditya", "Arjun", "Rohan", "Karan", "Rahul", "Amit", "Neha", "Priya",
         "Anjali", "Pooja", "Sneha", "Kavya", "Simran", "Riya", "Manpreet", "Harpreet", "Gurpreet",
         "Sanjay", "Deepak", "Vikram", "Meera", "Isha", "Tanvi", "Nikhil", "Sahil", "Divya", "Ankit", "Ritu"]
LAST = ["Sharma", "Verma", "Singh", "Gupta", "Patel", "Reddy", "Nair", "Iyer", "Das", "Mehta",
        "Kapoor", "Malhotra", "Joshi", "Bansal", "Chopra", "Kumar", "Agarwal", "Bose", "Shah", "Khanna"]

# (name, category, unit_price, unit_cost)
PRODUCTS = [
    ("Wireless Earbuds",     "Electronics", 2499, 1500),
    ("Smart Watch",          "Electronics", 4999, 3300),
    ("Bluetooth Speaker",    "Electronics", 1999, 1150),
    ("Power Bank 20000mAh",  "Electronics", 1499,  850),
    ("Gaming Mouse",         "Electronics", 1299,  700),
    ("Air Fryer",            "Home & Kitchen", 5499, 3600),
    ("Mixer Grinder",        "Home & Kitchen", 3299, 2100),
    ("Electric Kettle",      "Home & Kitchen",  999,  520),
    ("Non-stick Cookware Set","Home & Kitchen", 2799, 1500),
    ("Vacuum Flask",         "Home & Kitchen",  699,  320),
    ("Running Shoes",        "Fashion", 2999, 1500),
    ("Denim Jacket",         "Fashion", 2499, 1150),
    ("Leather Wallet",       "Fashion",  899,  350),
    ("Sunglasses",           "Fashion", 1599,  600),
    ("Backpack",             "Fashion", 1799,  800),
    ("Yoga Mat",             "Fitness",  799,  330),
    ("Dumbbell Set 10kg",    "Fitness", 1899,  950),
    ("Resistance Bands",     "Fitness",  499,  180),
    ("Fitness Tracker",      "Fitness", 2299, 1350),
    ("Protein Shaker",       "Fitness",  399,  140),
    ("Notebook Pack (5)",    "Stationery",  349,  120),
    ("Gel Pen Box (20)",     "Stationery",  249,   80),
    ("Desk Organizer",       "Stationery",  599,  230),
    ("Scientific Calculator","Stationery",  899,  400),
    ("Planner Diary 2026",   "Stationery",  449,  150),
]
# how popular each category is, and typical quantity
CATEGORY_WEIGHT = {"Electronics": 0.30, "Home & Kitchen": 0.22, "Fashion": 0.22,
                   "Fitness": 0.14, "Stationery": 0.12}

# month -> seasonality multiplier (festive spike in Oct-Dec)
SEASON = {1: 0.90, 2: 0.85, 3: 1.00, 4: 0.95, 5: 0.90, 6: 0.82,
          7: 0.88, 8: 1.00, 9: 1.05, 10: 1.40, 11: 1.45, 12: 1.25}


def weighted_choice(options, weights):
    return random.choices(options, weights=weights, k=1)[0]


def build_customers(n=650):
    rows = []
    for cid in range(1, n + 1):
        region = weighted_choice(list(REGION_WEIGHT), list(REGION_WEIGHT.values()))
        city = random.choice(CITIES[region])
        segment = weighted_choice(["Consumer", "Corporate", "Small Business"], [0.62, 0.18, 0.20])
        name = f"{random.choice(FIRST)} {random.choice(LAST)}"
        rows.append((cid, name, city, region, segment))
    return rows


def build_sales(customers, products):
    by_cat = {}
    for pid, (_, cat, _, _) in enumerate(products, start=1):
        by_cat.setdefault(cat, []).append(pid)

    # a few "loyal" customers buy far more often -> realistic top-customer list
    cust_ids = [c[0] for c in customers]
    cust_weights = [6 if random.random() < 0.08 else 1 for _ in customers]

    rows, sale_id = [], 1
    months_total = (END.year - START.year) * 12 + END.month - START.month
    day = START
    while day <= END:
        months_elapsed = (day.year - START.year) * 12 + day.month - START.month
        growth = 1 + 0.018 * months_elapsed                     # ~1.8% growth per month
        weekend = 1.15 if day.weekday() >= 5 else 1.0
        expected = 9 * SEASON[day.month] * growth * weekend
        n_orders = max(1, int(random.gauss(expected, 2.2)))

        for _ in range(n_orders):
            cat = weighted_choice(list(CATEGORY_WEIGHT), list(CATEGORY_WEIGHT.values()))
            pid = random.choice(by_cat[cat])
            cid = weighted_choice(cust_ids, cust_weights)
            qty = weighted_choice([1, 2, 3, 4], [0.62, 0.24, 0.10, 0.04])
            # bigger discounts during festive months
            festive = day.month in (10, 11, 12)
            discount = weighted_choice([0, 5, 10, 15, 20, 25],
                                       [0.30, 0.20, 0.20, 0.12, 0.10, 0.08] if festive
                                       else [0.55, 0.20, 0.15, 0.07, 0.03, 0.00])
            rows.append((sale_id, day.isoformat(), cid, pid, qty, discount))
            sale_id += 1
        day += timedelta(days=1)
    return rows


def main():
    if DB_PATH.exists():
        DB_PATH.unlink()

    con = sqlite3.connect(DB_PATH)
    con.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))

    customers = build_customers()
    products = [(i, n, c, p, k) for i, (n, c, p, k) in enumerate(PRODUCTS, start=1)]
    sales = build_sales(customers, PRODUCTS)

    con.executemany("INSERT INTO customers VALUES (?,?,?,?,?)", customers)
    con.executemany("INSERT INTO products  VALUES (?,?,?,?,?)", products)
    con.executemany("INSERT INTO sales     VALUES (?,?,?,?,?,?)", sales)
    con.commit()

    total_rev, total_profit = con.execute(
        "SELECT ROUND(SUM(revenue)), ROUND(SUM(profit)) FROM vw_sales_detail").fetchone()
    con.close()

    print(f"Database created: {DB_PATH.name}")
    print(f"  customers : {len(customers):,}")
    print(f"  products  : {len(products):,}")
    print(f"  sales rows: {len(sales):,}")
    print(f"  revenue   : Rs {total_rev:,.0f}   profit: Rs {total_profit:,.0f}")


if __name__ == "__main__":
    main()
